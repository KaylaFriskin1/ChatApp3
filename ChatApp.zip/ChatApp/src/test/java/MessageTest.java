



/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit5TestClass.java to edit this template
 */



import com.mycompany.chatapppart1.Message;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;






/**
 *
 * @author Student
 */
public class MessageTest {
    private Message msg;
    
    
   @BeforeEach
   public void setUp() {

       Message.clearArrays();
       msg = new Message();
 
   }
    @Test
    
    public void testSentMesagesArray_correctlyPopulated() {
        msg.sendMessage("Did you get the cake?", "+27834557896", "ID1", "HASH1");
        msg.sendMessage("It is dinner time!", "0838884567", "ID2", "HASH2");
        List<String> activeList = Message.sentMessages();
        assertTrue( activeList.contains("Did you get the cake?"));
        assertTrue(activeList.contains("It is dinner time!"));
        
    }
    @Test
    public void testDisplayLongestMessage_returnsCorrectMessage() {
        String expectedLongest = "Where are you? you are late! i have asked you to be on time";
        msg.sendMessage(expectedLongest, "+27838884567", "ID_L", "HASH_L");
        msg.sendMessage("Short text", "+27834557896", "ID_S", "HASH_S");
        String actualLongest = msg.displayLongestMessage();
        assertEquals(expectedLongest, actualLongest);
    }
    @Test
    public void testSearchByMessageID_returnsCorrectMessage() {
        String targetId = "0838884567";
        String targetText = "It is dinner time!";
        msg.sendMessage(targetText, "+27838884567", targetId, "HASH3");
        String result = msg.searchByMessageID(targetId);
        assertEquals(targetText, result);
        
    }
  @Test
  public void testSearchByRecipient_accumulatesReport() {
      String testRecipient = "+27838884567";
      String msg2 = "Where are you?, You are late! I have asked you to be on time.";
      String msg5 = "Test";
      msg.sendMessage(msg2, testRecipient, "ID2", "HASH2");
      msg.sendMessage(msg5, testRecipient, "ID5", "HASH5");
        String accumulatedReport = msg.searchByRecipient(testRecipient);
      assertTrue(accumulatedReport.contains(msg2));
      assertTrue(accumulatedReport.contains(msg5));
      
  }
  @Test
  public void testDeleteByHash_removesCorrectMessage() {
      String textHash = "HASH2";
      String textTest = "Where are you?, You are late! I have asked you to be on time";
      msg.sendMessage(textTest, "+27838884567", "ID2", textHash);
      String expectedFeedback = "Message: " + textTest + " successfully deleted";
      String actualFeedback = msg.deleteByHash(textHash);
      assertEquals(expectedFeedback, actualFeedback);
  }
  @Test
  public void testDisplayReport_containsRequiredFields() {
      msg.sendMessage("Testing layout parameters", "+27834557896", "ID123", "REPORT_HASH_123");
      String systemReportOutput = Message.displayReport();
      assertTrue(systemReportOutput.contains("REPORT_HASH_123"));
      
              assertTrue(systemReportOutput.contains("+27834557896"));
              
              assertTrue(systemReportOutput.contains("Testing layout parameters"));
  }
  
    /**
     * Test of createMessageHash method, of class Message.
     */
    @Test
    public void testCreateMessageHash() {
        Message msg = new Message();
        String messageID = "12345";
        int messageNumber = 1;
         String messageText = "Hello";

          String expResult = "12:1:HELLO"; 
          String result = msg.createMessageHash(messageID, messageNumber, messageText);
          assertEquals(expResult, result);

        
        
 
    }

}
