/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

import java.util.Scanner;

/**
 *
 * @author Student
 */
public class   MainApp {

    private static Object sebMenuProcessor;
    private static Object input;
    public static void main(String[] args, Scanner scanner) {
        
        //Scanner allows user to enter information
        Scanner input = new Scanner(System.in);
        
        //create a object in the Login class so that we can call its methods
        Login login = new Login();
        
        //---Registration Section---
        System.out.println("=== User Registration ===");
        
        System.out.print("Enter a username: ");
        String username = input.nextLine();
        
        System.out.print("Enter a password: ");
        String password = input.nextLine();
        
        System.out.print("Enter your South African number (+27...): ");
        String phone = input.nextLine();
        
        //Call the registerUser method and store the message it returns
        String response = login.registerUser(username,password,phone);
        
        //Show the registration message
        System.out.println(response);
        
        //--Login Section---
        System.out.println("\n--- User Login ---");
        
        System.out.print("Enter your username: ");
        String loginUsername = input.nextLine();
        
        System.out.print("Enter your password: ");
        String loginPassword = input.nextLine();
        
        //Call loginUser to check if details match the stored ones
        boolean loggedIn = login.loginUser(loginUsername,loginPassword);
        
        //Print out the correct login message
        String loginMessage = login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
        
        if (loggedIn);{
        System.out.println("Welcome to ChattApp.");}
        {
                System.out.println("Please try again,invalid details");
                }
        boolean running = true;
        while (running) {
           System.out.println("1) Send messages"); 
            System.out.println("2) Show recently sent messages");
            System.out.println("3) Quit");
            System.out.println("4.)Stored messages");
        int choice = Integer.parseInt(input.nextLine());
        switch (choice) {
            case 1 -> {
                System.out.println("How many messages would you like to send?");
                int totalMessages = Integer.parseInt(input.nextLine());
                input.nextLine();
           for (int i = 0; i < totalMessages; i++){
                    int messageNumber = i + 1;
                    System.out.println("\n---Message " + messageNumber + "---");
                    System.out.println("Enter recipient number: ");
                    String recipient = input.nextLine();
                    System.out.println("Enter your message: ");
                    String text = input.nextLine();
                  
                   Message msg = new Message(recipient, text, messageNumber);
                msg.printMessage(); 
               
                }
                System.out.println("Enter message: ");
                
                }

            case 2 -> { String report = Message.displayReport();
                     System.out.println(report); }
            case 3 -> {
                System.out.println("Goodbye");
                running = false;
                }
            case 4 -> {storedMessagesSubMenu(scanner);}
            default -> System.out.println("Invalid option,please select between 1,2 or 3");
}   
        }
    }
    private static void storedMessagesSubMenu(Scanner scanner) {
        Message subMenuProcessor = new Message("","", 0);
        boolean inSubMenu = true;
        while (inSubMenu) {
            System.out.println("===STORED MESSAGES SUB-MENU====");
            System.out.println("a) Display allstored messages");
            System.out.println("b) Display by message ID");
            System.out.println("c) Display by recipient");
            System.out.println("d) Delete by message hash");
            System.out.println("e) Display full report");
            System.out.println("g) Return to main menu");
            System.out.println("Select an option (a-g): ");
            String option = scanner.nextLine().toLowerCase().trim();
            switch (option) {
                case "b" -> {System.out.println("\nLongest Recorded Message");
                    System.out.println(subMenuProcessor.displayLongestMessage());
                }
                case "c" -> { System.out.println("\nEnter Message ID to look up: ");
                String lookUpId = scanner.nextLine();
                    
                    System.out.println("Result: " + subMenuProcessor.searchByMessageID(lookUpId));
                }
                case "d" -> { System.out.println("\nEnter the recipient number to search: ");
                String lookUpRecipient = scanner.nextLine();
                System.out.println("\n---Search Results--");
                    System.out.println(subMenuProcessor.searchByRecipient(lookUpRecipient));
                }
                case "e" -> {System.out.println("\nEnter Message Hash to delete: ");
                String deleteHash = scanner.nextLine();
                    System.out.println(subMenuProcessor.deleteByHash(deleteHash));
                }
                case "f" -> { System.out.println("\n---Full sent History Report");
                    System.out.println(Message.displayReport());
                }
                case "g" -> { System.out.println("Returning to Main Menu dashboard...");
                inSubMenu= false;
                }
                default -> System.out.println("Invalid option selection.Please enter a letter from a to g");
            }
        }
    }
    
    
}
