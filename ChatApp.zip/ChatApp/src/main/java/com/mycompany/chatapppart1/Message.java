/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

/**
 *
 * @author Student
 */
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONObject;

public class Message {

    public static List<String> sentMessages() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }

    private Object sendMessages;

    public Message(){}
//This will run when a message gets ent and saves all the details
    //into the storage list
    public void sendMessage(String text, String recipient,String id, String hash){
        this.messageText = text;
        this.recipient = recipient;
        sentMessages.add(messageText);
        recipientList.add(recipient);
        messageHashes.add(this.messageHash);
        messageIDs.add(this.messageID);
        allMessages.add(new MessageEntry(text, this.messageHash, this.messageID, recipient));
    }
    //Gives back the entire list of text messages
    public static ArrayList<String> sentMessages(ArrayList<String> sendMessage) {
        return sendMessage;
    }
    //Avoids all messages from mixing into the new testing sessions.
    public static void clearArrays() {
        sentMessages.clear();
        recipientList.clear();
        messageHashes.clear();
        messageIDs.clear();
        allMessages.clear();
    }

   //The single message details 
    private String messageID;
    private int messageNumber;
    private String recipient;
    private String messageText;
    private String messageHash;
    
    //--Parallel Arrays
    private static ArrayList<String> sentMessages = new ArrayList<>();
    private static ArrayList<String> disregardMessages = new ArrayList<>();
    private static ArrayList<String> storedMessages = new ArrayList<>();
    private static ArrayList<String> messageHashes = new ArrayList<>();
    private static ArrayList<String> messageIDs = new ArrayList<>();
    private static ArrayList<String> recipientList = new ArrayList<>();

   
   
    
   

    public static class MessageEntry {
     String messageText, messageHash, messageID, recipient;
     public MessageEntry(String messageText, String messageHash, String messageID, String recipient) {
         this.messageText = messageText;
         this.messageHash = messageHash;
         this.messageID = messageID;
         this.recipient = recipient;
     }
    }
    private static ArrayList<MessageEntry> allMessages = new ArrayList<>();
    
    public Message(String recipient, String messageText, int messageNumber) {
        this.recipient = recipient;
        this.messageText = messageText;
        this.messageNumber = messageNumber;
    }
//Checking if recipient's phone number is valid
    public boolean checkMessageID(String messageID) {
        if (messageID == null) {
            return false;
        }

        return messageID.length() == 12 || messageID.length() == 10;
    }

    public boolean checkRecipientCell(String recipient) {
        if (recipient != null && recipient.startsWith("+ 27") && recipient.length() <= 13) {
            return true;
        }
            return false;
        }
    
//Combines the messageID, message number, first name, and last words of the text together
    public String createMessageHash(String messageID, int messageNumber, String messageText) {
        if (messageID == null || messageID.length() < 2 || messageText == null || messageText.isEmpty()) {
            return "Default hash";
        }
        
        String firstTwo = messageID.substring(0, 2);
        String[] words = messageText.split(" ");
        String firstWord = words[0].toUpperCase();
        
        String hash = firstTwo + ":" + messageNumber + ":" + firstWord;
        this.messageHash = hash;
        return hash;
    }
    

    public void processMessageAction(int choice) {
        switch (choice) {
            
            case 1 -> {
                sentMessages.add(this.messageText);
                messageHashes.add(this.messageHash);
                messageIDs.add(this.messageID);
                recipientList.add(this.recipient);
                System.out.println("Message sent successfully");
            }
            case 2 -> {
                messageHashes.add(this.messageHash);
                messageIDs.add(this.messageID);
                recipientList.add(this.recipient);
                System.out.println("Message stored safely");
            }
            case 3 -> {
                System.out.println("Message disregarded");
            }
            default -> {
                //user selected incorrect option
                System.out.println("Invalid selection");
            }

        }
    }

    public static void loadStoredMessages() {
        File file = new File("messages.json");
        if (!file.exists()) {
            return;
        }
        
            try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    try {
                        JSONObject jsonObject = new JSONObject(line);
                        String extractedText = jsonObject.getString("messageText");
                        storedMessages.add(extractedText);
                    } catch (org.json.JSONException jdonEx) {
                        System.out.println("This is not a valid JSON string " + line);
                    }
                }
            } catch (IOException e) {
                System.out.println("No previous messages found or file is empty");
            }
        }
    
    

    public String displayLongestMessage() {
       
      String longest = " ";
      for (String msg : sentMessages) {
    if (msg.length() > longest.length()) {
    longest = msg;}
       }

       return longest;
    }

    public String searchByMessageID(String id) {
        for (MessageEntry entry : allMessages) {
       if (entry.messageID != null & entry.messageID.equals(id)) {
       
        return "Recipient: "
                + entry.recipient
                + "\nMessage: "
                + entry.messageText;
            }
        }
        return "Message not found";

    }

    public String searchByRecipient(String recipient) {
        StringBuilder results = new StringBuilder();
 
       
        for (MessageEntry entry : allMessages) {
            if (entry.recipient != null && recipient.equals(recipient)) {
                
                results.append(entry.messageText).append("\n");
                }
               
             }
        
        if (results.length() == 0) {
            
        
      return "No messages found";
        }
      return results.toString();
    
    }
    public  String deleteByHash(String hash) {
     
        //Idenitfying the index
        for (int i = 0; i < allMessages.size(); i++) {
            MessageEntry entry = allMessages.get(i);
            if (entry.messageHash != null && entry.messageHash.equals(hash)){
              String msg = entry.messageText;
              storedMessages.remove(i);
              messageIDs.remove(i);
               recipientList.remove(i);
               messageHashes.remove(i);
               
            return "Message: " + msg + " successfully deleted";
            }
        }
        
        return "Message not found";
    }

  
    public static String displayReport() {
        StringBuilder report = new StringBuilder();
        report.append("===MESSAGE REPORT===\n");
        for (MessageEntry entry : allMessages) {
            report.append("REPORT_HASH: ").append(entry.messageHash).append("\n")
                   .append("REPORT_RECIPIENT: ").append(entry.recipient).append("\n")
                  .append("REPORT_MESSAGE: ").append(entry.messageText).append("\n")
                    .append("------------------------------------------\n");
                  
        }
        return report.toString();
    }
public void printMessage() {
    System.out.println(this.messageText);
     
 }  

  
    }

    

